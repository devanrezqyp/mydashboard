# Tutorial Build

 Home Page : https://www.infotechku.com/2020/11/tutorial-membuat-tampilan-aplikasi-ovo-di-android-studio-homepage.html
 
 
 Top up Page : https://www.infotechku.com/2020/11/tutorial-membuat-tampilan-aplikasi-ovo-di-android-studio-topup-page.html
 
# UI-OVO

<table style="width:100%">
  <tr>
    <th>1. Demo </th>
    <th>2. Demo</th> 
    <th>3. Demo </th>
    <th>4. Demo</th> 
  </tr>
  <tr>
    <td><img src = "https://user-images.githubusercontent.com/71577391/99693676-37029100-2abe-11eb-96de-e7c999406740.jpg"/></td>
    <td><img src = "https://user-images.githubusercontent.com/71577391/99693690-3a961800-2abe-11eb-9302-64622c3a3525.jpg"/></td>
    <td><img src = "https://user-images.githubusercontent.com/71577391/99905827-e5e4de00-2d05-11eb-81f1-eac628d8bcc6.jpeg"/></td>
    <td><img src = "https://user-images.githubusercontent.com/71577391/99905828-e9786500-2d05-11eb-8ae1-705c50ff20f4.jpeg"/></td>

  </tr>
</table>



![Screenshot_38](https://user-images.githubusercontent.com/53173709/99906415-9accca00-2d09-11eb-9a21-6a533c669af3.png)
![Screenshot_45](https://user-images.githubusercontent.com/53173709/99906420-9f917e00-2d09-11eb-9b0c-4c7f0a3bde98.png)
