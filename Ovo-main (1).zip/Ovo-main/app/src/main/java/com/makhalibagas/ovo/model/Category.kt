package com.makhalibagas.ovo.model

class Category (

    val icon : Int,
    val name : String

)