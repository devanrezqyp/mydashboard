package com.makhalibagas.ovo.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class Metode (

    val icon : Int,
    val name : String

) : Parcelable