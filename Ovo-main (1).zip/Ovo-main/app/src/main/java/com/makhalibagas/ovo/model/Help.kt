package com.makhalibagas.ovo.model

class Help (

    val icon : Int,
    val name : String

)